package com.nyuad.gulflens

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform