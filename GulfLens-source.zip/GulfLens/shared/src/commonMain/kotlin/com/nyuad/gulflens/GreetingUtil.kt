package com.nyuad.gulflens

fun sayHello(to: String): String =
    "Hello, $to!"